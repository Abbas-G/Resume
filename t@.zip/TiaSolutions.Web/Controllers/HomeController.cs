﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Mail;
using System.Configuration;
using TiaSolutions.Web.Models;
namespace TiaSolutions.Web.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            //if (Session["abbas"].ToString() == "a")
            //{ }

            return View();
        }
        public ActionResult Approach()
        {
            return View();
        }

        public ActionResult Career()
        {
            return View();
        }

        public ActionResult Technologies()
        {
            return View("MSDotNet");
        }

        public ActionResult MobileApp()
        {
            return View();
        }

        public ActionResult MSDotNet()
        {
            return View();
        }
        public ActionResult ContactUs()
        {
            return View();
        }
        public ActionResult Apply(string position)
        {
            return RedirectToAction("Apply", "Career", new { position = position });
        }

        public ActionResult AboutUs()
        {
            return View();
        }

        public ActionResult Portfolio()
        {

            return View("Portfolio3");
        }

        public ActionResult Portfolio3()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ContactUs(FormCollection result)
        {
            if (result["txtName"] != null && result["txtEmail"] != null)
            {
                try
                {
                    //SmtpClient client = new SmtpClient(ConfigurationSettings.AppSettings["smtpServer"].ToString());
                    //System.Net.NetworkCredential cred = new System.Net.NetworkCredential(ConfigurationSettings.AppSettings["UserID"].ToString(), ConfigurationSettings.AppSettings["Password"].ToString());
                    //client.Credentials = cred;
                    //client.Port = 587;
                    //client.EnableSsl = true;
                    ////client.UseDefaultCredentials = false;
                    //client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    string messageBody = "<div style='font:11px/1.35em Verdana, Arial, Helvetica, sans-serif;'><p>";
                    messageBody += "<b>Name    :&nbsp;</b>" + result["txtName"] + "<br>";
                    messageBody += "<b>Subject :&nbsp;</b>" + result["txtSubject"] + "<br>";
                    messageBody += "<b>Phone   :&nbsp;</b>" + result["txtPhone"] + "<br>";
                    messageBody += "<b>Email    :&nbsp;</b>" + result["txtEmail"] + "<br>";
                    messageBody += "<b>Message    :&nbsp;</b>" + result["txtMessage"] + "<br>";
                    messageBody += "<br>";
                    if (!string.IsNullOrEmpty(Request.UserHostAddress))
                    {
                        messageBody += "<b>IP Address  :&nbsp;</b>" + Request.UserHostAddress + "<br>";
                    }
                    if (!string.IsNullOrEmpty(Request.ServerVariables["HTTP_USER_AGENT"]))
                    {
                        messageBody += "<b>Browser     :&nbsp;</b>" + Request.Browser.Browser + "<br>";
                    }
                    messageBody += "</p></div>";

                    string subject = "Enquiry: TiaSolutions.com: " + result["txtName"];

                    //MailAddress to = new MailAddress(ConfigurationSettings.AppSettings["MailTo"].ToString());
                    //MailAddress from = new MailAddress("contact@iprogrammer.com.au", "TiaSolutions", System.Text.Encoding.UTF8);
                    //MailAddress cc = new MailAddress(ConfigurationSettings.AppSettings["MailCC"].ToString());
                    //MailAddress replyto = new MailAddress(ConfigurationSettings.AppSettings["ReplyTo"].ToString());
                    //MailMessage message = new MailMessage(from, to);
                    //message.CC.Add(cc);
                    //message.ReplyTo = replyto;
                    //message.Subject = subject;
                    //message.Priority = MailPriority.High;
                    //message.Body = messageBody;
                    //message.IsBodyHtml = true;
                    //client.Send(message);
                    if(TiaSolutions.Web.Models.Helper.SendEMail(subject, messageBody))
                    ViewData["message"] = "<span><label style='color:green'>Thank you for your enquiry. Some one would be in touch with you as soon as possible.</label></span>";
                    else
                        ViewData["message"] = "<span><label style='color:red;font-size:large'>Server Error!.</label></span>";
                    return View();
                }
                catch (Exception ex)
                {
                    //Response.Redirect("contactus.html");
                    ViewData["message"] = "<span><label style='color:red;font-size:large'>Error! please try again.(" + ex.ToString() + ")</label></span>";
                    return View();
                }
            }
            else
            {
                ViewData["message"] = "<span><label style='color:red;font-size:large'>Error! please try again.</label></span>";
                return View();
            }
        }

       
    }
}
