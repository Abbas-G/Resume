﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TiaSolutions.Web.Areas.admin.Controllers
{

    public class TPController : Controller
    {
        //
        // GET: /admin/TP/
        TiaSolutions.Core.Manager.AdminManager AM = new TiaSolutions.Core.Manager.AdminManager();
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetTPDetails()
        {
            List<TiaSolutions.Core.DAL.Application> list = AM.getTPDetail();

            var ListWitoutFK = list.Select(x => new
            {
                ID = x.Id,
                Name = x.FirstName + " " + x.LastName,
                Resume = x.ResumeName,
                City = x.City,
                Education = x.Education,
                Designation = x.Designation,
                ExpInYr = x.TotalExperienceInYear,
                ExpInMonth = x.TotalExperienceInMonth,
                ExpInTotalMonth = x.TotalExperienceInYear * 12 + x.TotalExperienceInMonth,
                ExpectedSalary = x.ExpectedSalaryInYear,
                ModifiedDate = x.DateTime,
                Age = x.Age,
                Gender = x.Gender,
                Tel = x.PhoneNo,
                Email = x.Email,
                NoticePeriod = x.NoticePeriodInWeek,
                CurrentSalary = x.CurrentSalaryInYear
            });

            return Json(ListWitoutFK, JsonRequestBehavior.AllowGet); // when table as primary key foreign key relation at that time circular reference error arise when using jaso so create new obj and then send jason value
        }
    }
}
