﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TiaSolutions.Web.Areas.admin.Models;
using System.Web.Security;

namespace TiaSolutions.Web.Areas.admin.Controllers
{

    public class AccountController : Controller
    {
        //
        // GET: /admin/Account/

        #region "Login"
        public ActionResult Login()
        {
            ViewData["Message"] = "";
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Login(LoginModel model, string returnUrl) // model refer to LoginModel in LoginModel Model 
        {
            if (ModelState.IsValid)
            {

                TiaSolutions.Core.Manager.AdminManager AM = new TiaSolutions.Core.Manager.AdminManager();
                TiaSolutions.Core.DAL.Login usr = AM.LoginUser(model.UserName, model.Password);
                if (usr != null)
                {
                    FormsAuthentication.Initialize();
                    FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, usr.UserName.ToString(), DateTime.Now, DateTime.Now.AddMinutes(30), model.RememberMe, FormsAuthentication.FormsCookiePath);
                    string hash = FormsAuthentication.Encrypt(ticket);
                    HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, hash);
                    if (ticket.IsPersistent) cookie.Expires = ticket.Expiration;
                    Response.Cookies.Add(cookie);
                    if ((!String.IsNullOrEmpty(returnUrl)) && returnUrl.Length > 1)
                        return Redirect(returnUrl);
                    else
                    {
                        return RedirectToAction("Index", "List", new { area = "admin" });
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Incorrect user name or password.");
                }
            }
            return View(model);
        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            Session.Clear();

            return RedirectToAction("Login", "Account", new { area = "admin" });
        }
        #endregion

    }
}
