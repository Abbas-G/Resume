﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TiaSolutions.Web.Areas.admin.Controllers
{

    public class ListController : Controller
    {
        //
        // GET: /admin/List/
        TiaSolutions.Core.Manager.AdminManager AM = new TiaSolutions.Core.Manager.AdminManager();
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult GetApplicantDetails()
        {
            List<TiaSolutions.Core.DAL.Application> list = AM.getApplicantDetail();

            var ListWitoutFK = list.Select(x => new
            {
                ID = x.Id,
                Name = x.FirstName+" "+x.LastName,
                Resume=x.ResumeName,
                City = x.City,
                Education = x.Education,
                Designation = x.Designation,
                ExpInYr = x.TotalExperienceInYear,
                ExpInMonth = x.TotalExperienceInMonth,
                ExpInTotalMonth=x.TotalExperienceInYear*12+x.TotalExperienceInMonth,
                ExpectedSalary=x.ExpectedSalaryInYear,
                ModifiedDate = x.DateTime,
                Age=x.Age,
                Gender=x.Gender,
                Tel=x.PhoneNo,
                Email=x.Email,
                NoticePeriod=x.NoticePeriodInWeek,
                CurrentSalary=x.CurrentSalaryInYear
            });

            return Json(ListWitoutFK, JsonRequestBehavior.AllowGet); // when table as primary key foreign key relation at that time circular reference error arise when using jaso so create new obj and then send jason value
        }

        public JsonResult GetJsonOutputUniqueGroupbyData()
        {
            List<string> list = AM.getUniqueGroubyData();
            return Json(list);  // this statement wont allow to see records directly on browser
        }
        [HttpPost]
        public ActionResult DeleteRecords(int id)
        {
            bool a = AM.DeleteRecordById(id);
            return Json(new { Value = "Id:" + id + " deleted Successfully" });
        }

        [HttpPost]
        public ActionResult MoveToICP(int id)
        {
            bool a = AM.MoveToICPById(id);
            return Json(new { Value = "Id:" + id + " Moved Successfully" });
        }

        [HttpPost]
        public ActionResult MoveToTP(int id)
        {
            bool a = AM.MoveToTPById(id);
            return Json(new { Value = "Id:" + id + " Moved Successfully" });
        }

        [HttpPost]
        public ActionResult MoveToArchive(int id)
        {
            bool a = AM.MoveToArchiveById(id);
            return Json(new { Value = "Id:" + id + " Moved Successfully" });
        }

        [HttpPost]
        public ActionResult setWeHire(bool val)
        {
            TiaSolutions.Web.Models.FileHelper FH = new TiaSolutions.Web.Models.FileHelper();
            FH.SetWeHire(val);
            return Json(new { Value = "set successfullly" });
        }
    }
}
