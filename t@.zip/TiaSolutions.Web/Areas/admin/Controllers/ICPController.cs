﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;
namespace TiaSolutions.Web.Areas.admin.Controllers
{
    public class ICPController : Controller
    {
        //
        // GET: /admin/ICP/
        TiaSolutions.Core.Manager.AdminManager AM = new TiaSolutions.Core.Manager.AdminManager();
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetICPDetails()
        {
            List<TiaSolutions.Core.DAL.Application> list = AM.getICPDetail();

            var ListWitoutFK = list.Select(x => new
            {
                ID = x.Id,
                Name = x.FirstName + " " + x.LastName,
                Resume = x.ResumeName,
                City = x.City,
                Education = x.Education,
                Designation = x.Designation,
                ExpInYr = x.TotalExperienceInYear,
                ExpInMonth = x.TotalExperienceInMonth,
                ExpectedSalary = x.ExpectedSalaryInYear,
                ModifiedDate = x.DateTime,
                Age = x.Age,
                Gender = x.Gender,
                Tel = x.PhoneNo,
                Email = x.Email,
                NoticePeriod = x.NoticePeriodInWeek,
                CurrentSalary = x.CurrentSalaryInYear,
                InterviewDate=x.InterviewDate,
                Status=x.Status,
                FeedBack_SM=x.Feedback_SM,
                FeedBack_BC=x.Feedback_BC,
                Rating=x.Rating,
                time = getTime(x.InterviewDate)
            });

            return Json(ListWitoutFK, JsonRequestBehavior.AllowGet); // when table as primary key foreign key relation at that time circular reference error arise when using jaso so create new obj and then send jason value
        }

        public string getTime(DateTime? dt)
        {
            DateTime? a = dt;
            if (dt!=null)
            {
               // string b = Convert.ToDateTime(dt).ToString("HH:mm");
                return Convert.ToDateTime(dt).ToShortTimeString();
            }
            else
                return null ;
        }

        [HttpPost]
        public ActionResult editRow(string id, string status, string SM, string BC, string rating)
        {
            try
            {
                TiaSolutions.Core.DAL.Application data = new TiaSolutions.Core.DAL.Application();
                data.Id = Convert.ToInt32(id);
                data.Status = status;
                if (!string.IsNullOrEmpty(rating))
                    data.Rating = Convert.ToInt32(rating);
                else
                    data.Rating = 0;

                if (!string.IsNullOrEmpty(BC))
                    data.Feedback_BC = BC;
                else
                    data.Feedback_BC = null;

                if (!string.IsNullOrEmpty(SM))
                    data.Feedback_SM = SM;
                else
                    data.Feedback_SM = null;

                if (AM.UpdateInfo(data))
                    return Json(new { Value = true });
                else
                    return Json(new { Value = false });
            }
            catch (Exception e)
            {
                return Json(new { Value = false });
            }
        }

        [HttpPost]
        public ActionResult editRowMail(string id, string status, string name, string designation, string email, string InterviewDate, string InterviewTime)
        {
            string Designtn = checkDesignation(designation);
            string messageBody = "Dear " + name + ",<br/><br/>";
            messageBody += "Tia Solutions inviting you for an interview for the post of " + Designtn + " on <b>" + InterviewDate + "</b> at <b>" + InterviewTime + "</b>.<br>";
            messageBody += "Bring your resumes hard-copy and all other relevant documents.<br>";
            messageBody += "Please confirm your interview schedule by replaying on this email or let us know convenient time for you.<br>";
            messageBody += "If you have any query, feel free to call us on: 99740 07966.<br><br>";
            messageBody += "<h3>Office Address:</h3>";
            messageBody += "Tia Solutions,<br>";
            messageBody += "Level 2,<br>";
            messageBody += "5 Deepmangal Soc.<br>";
            messageBody += "N/RKaviNarmad Library,</b><br>";
            messageBody += "Athwalines, Ghoddod Road, Surat.<br/><br/>";
            messageBody += "<img src='http://www.tia-solutions.com/Content/images/customLogo.png'/><br>";

            string subject = "Invitation for Interview: Tia-Solutions.com";

            if (TiaSolutions.Web.Models.Helper.SendEMailToCandidate(subject, messageBody, email))
            {
                try
                {
                    TiaSolutions.Core.DAL.Application data = new TiaSolutions.Core.DAL.Application();
                    data.Id = Convert.ToInt32(id);
                    if (InterviewTime != null)
                    {
                        string dt = InterviewDate + " " + InterviewTime;
                        data.InterviewDate = ParseDate(dt);// Convert.ToDateTime();
                    }
                    else
                        data.InterviewDate = Convert.ToDateTime(InterviewDate);

                    data.Status = status;

                    if (AM.UpdateInfoMail(data))
                        return Json(new { Value = true });
                    else
                        return Json(new { Value = false });
                }
                catch (Exception e)
                {
                   // return Json(new { Value = e.ToString() + " " + ParseDate(InterviewDate + " " + InterviewTime).ToString()});
                    return Json(new { Value = false });
                }
            }
            else
                return Json(new { Value = false });
        }

        public DateTime ParseDate(string date)
        {
            DateTimeFormatInfo dateFormatProvider = new DateTimeFormatInfo();
            dateFormatProvider.ShortDatePattern = "dd/MM/yyyy hh:mm tt";

            return DateTime.Parse(date, dateFormatProvider);
        }
        
        [HttpPost]
        public ActionResult editRowMailModify(string id, string name, string designation, string email, string InterviewDate, string InterviewTime)
        {
            string Designtn = checkDesignation(designation);
            string messageBody = "Dear " + name + ",<br/><br/>";
            messageBody += "Tia Solutions would like to reschedule your Interview for the post of " + Designtn + " on <b>" + InterviewDate + "</b> at <b>" + InterviewTime + "</b>.<br>";
            messageBody += "Bring your resumes hard-copy and all other relevant documents.<br>";
            messageBody += "Please confirm your interview schedule by replaying on this email or let us know convenient time for you.<br>";
            messageBody += "If you have any query, feel free to call us on: 99740 07966.<br><br>";
            messageBody += "<h3><b>Office Address:</h3>";
            messageBody += "Tia Solutions,<br>";
            messageBody += "Level 2,<br>";
            messageBody += "5 Deepmangal Soc.<br>";
            messageBody += "N/RKaviNarmad Library,<br>";
            messageBody += "Athwalines, Ghoddod Road, Surat.<br/><br/>";
            messageBody += "<img src='http://www.tia-solutions.com/Content/images/customLogo.png'/><br>";

            string subject = "Interview ReSchedule on " + InterviewDate + " at " + InterviewTime + " : Tia-Solutions.com";

            if (TiaSolutions.Web.Models.Helper.SendEMailToCandidate(subject, messageBody, email))
            {
                try
                {
                    TiaSolutions.Core.DAL.Application data = new TiaSolutions.Core.DAL.Application();
                    data.Id = Convert.ToInt32(id);
                    if (InterviewTime != null)
                    {
                        string dt = InterviewDate + " " + InterviewTime;
                        data.InterviewDate = ParseDate(dt);// Convert.ToDateTime();
                       // data.InterviewDate = Convert.ToDateTime(InterviewDate + " " + InterviewTime);
                    }
                    else
                        data.InterviewDate = Convert.ToDateTime(InterviewDate);

                    if (AM.ModifyMailSchedule(data))
                        return Json(new { Value = true });
                    else
                        return Json(new { Value = false });
                }
                catch (Exception e)
                {
                    return Json(new { Value = false });
                }
            }
            else
                return Json(new { Value = false });
        }

        public string checkDesignation(string D)
        {
            if (D == "DotNet")
                return "ASP.net [C#] Developer";
            if (D == "Ios")
                return "iPhone [iOS] Developer";
            if (D == "WebDesigner")
                return "Web Designer";

            return null;
        }
    }
}
