﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace TiaSolutions.Web.Models
{
    public class FileHelper
    {
        public bool checkCSS()
        {
            //using (StreamWriter lohw = new StreamWriter("~/")) { 
            //    lohw.Write("",false);  
            //}
            bool chk = true;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath("~/Content/css/styleWeHire.css")))
            {

                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string str = line;
                    if (str.Contains("block"))
                        chk = false;
                }
            }
            return chk;
        }

        public void SetWeHire(bool value)
        {
            if (value)
            {
                using (StreamWriter lohw = new StreamWriter(System.Web.HttpContext.Current.Server.MapPath("~/Content/css/styleWeHire.css")))
                {
                    lohw.WriteLine(".isShow{display:block !important;}");
                }
            }
            else
            {
                using (StreamWriter lohw = new StreamWriter(System.Web.HttpContext.Current.Server.MapPath("~/Content/css/styleWeHire.css")))
                {
                    lohw.WriteLine(".isShow{display:none !important;}");
                }
            }
        }
    }
}
