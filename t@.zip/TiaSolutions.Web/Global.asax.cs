﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace TiaSolutions.Web
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "Default", // Route name
                "{controller}/{action}/{id}", // URL with parameters
                new { controller = "Home", action = "Index", id = UrlParameter.Optional } // Parameter defaults
               // new { controller = "Career", action = "Index", id = UrlParameter.Optional } // Parameter defaults
            );

        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            RegisterRoutes(RouteTable.Routes);
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();
            if (exception != null)
            {
                // --- Catch Exception --- //
                string lsMessage = exception.Message;
                if (exception.InnerException != null)
                    lsMessage += " \n Inner:" + exception.InnerException.Message;

                string lsStack = exception.StackTrace;
                TiaSolutions.Core.Manager.UtilityManager UM = new TiaSolutions.Core.Manager.UtilityManager();
                UM.LogError(lsMessage, lsStack);
                //Server.TransferRequest(System.Configuration.ConfigurationManager.AppSettings["host"].ToString() + "Error");
            }
        }


        void writeLog(string fsError)
        {
            try
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.AppendLine("--------------------------------------------------------------------------" + System.Environment.NewLine);
                sb.AppendLine(DateTime.Now.ToString() + System.Environment.NewLine);
                sb.AppendLine("Description: " + fsError);
                sb.AppendLine("--------------------------------------------------------------------------" + System.Environment.NewLine);


                string strFilePath = System.Configuration.ConfigurationManager.AppSettings["logpath"].ToString();
                System.IO.File.AppendAllText(strFilePath + "appLog.txt", sb.ToString());
            }
            catch (Exception ex)
            {

            }
        }

    }
}